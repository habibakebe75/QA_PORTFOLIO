
# Cypress — Demo Bank Smoke

**Run**
```bash
cd cypress
npm install
npm run test
```
